// Date.h
class Date {
public:
    void set(int m, int d, int y);
    void print();
private:
    int month, day, year;
};
