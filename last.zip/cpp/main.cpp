// main.cpp
#include "Date.h"


int main(void) {
    Date date;
    date.set(1,29,2012);
    date.print();
    return 0;
}
